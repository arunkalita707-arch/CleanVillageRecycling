package com.example.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface AppDao {
    @Query("SELECT * FROM users WHERE username = :username")
    suspend fun getUserByUsername(username: String): User?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUser(user: User): Long

    @Query("SELECT * FROM members ORDER BY name ASC")
    fun getAllMembers(): Flow<List<Member>>

    @Query("SELECT * FROM members WHERE qrCode = :qrCode")
    suspend fun getMemberByQrCode(qrCode: String): Member?

    @Query("SELECT * FROM members WHERE id = :id")
    fun getMemberById(id: Int): Flow<Member?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMember(member: Member): Long

    @Query("UPDATE members SET totalPoints = totalPoints + :points WHERE id = :memberId")
    suspend fun addPointsToMember(memberId: Int, points: Int)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCollection(entry: CollectionEntry): Long

    @Query("SELECT * FROM collections WHERE memberId = :memberId ORDER BY timestamp DESC")
    fun getCollectionsForMember(memberId: Int): Flow<List<CollectionEntry>>

    @Query("SELECT * FROM collections ORDER BY timestamp DESC")
    fun getAllCollections(): Flow<List<CollectionEntry>>
}
