package com.example.data

import kotlinx.coroutines.flow.Flow

class AppRepository(private val dao: AppDao) {
    val allMembers: Flow<List<Member>> = dao.getAllMembers()
    val allCollections: Flow<List<CollectionEntry>> = dao.getAllCollections()

    suspend fun getUserByUsername(username: String): User? = dao.getUserByUsername(username)
    suspend fun insertUser(user: User): Long = dao.insertUser(user)

    suspend fun getMemberByQrCode(qrCode: String): Member? = dao.getMemberByQrCode(qrCode)
    fun getMemberById(id: Int): Flow<Member?> = dao.getMemberById(id)
    suspend fun insertMember(member: Member): Long = dao.insertMember(member)

    suspend fun addPointsToMember(memberId: Int, points: Int) = dao.addPointsToMember(memberId, points)

    suspend fun insertCollection(entry: CollectionEntry): Long = dao.insertCollection(entry)
    fun getCollectionsForMember(memberId: Int): Flow<List<CollectionEntry>> = dao.getCollectionsForMember(memberId)
}
