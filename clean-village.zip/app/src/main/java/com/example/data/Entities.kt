package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.io.Serializable

enum class Role {
    ADMIN, OFFICER, MEMBER
}

@Entity(tableName = "users")
data class User(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val username: String,
    val role: Role,
    val memberId: Int? = null // if role == MEMBER
)

@Entity(tableName = "members")
data class Member(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val qrCode: String,
    val totalPoints: Int = 0,
    val joinedDate: Long = System.currentTimeMillis()
) : Serializable

@Entity(tableName = "collections")
data class CollectionEntry(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val memberId: Int,
    val officerId: Int,
    val weightKg: Double,
    val points: Int,
    val timestamp: Long = System.currentTimeMillis(),
    val location: String? = null,
    val photoUri: String? = null
) : Serializable
