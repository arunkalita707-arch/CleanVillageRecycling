package com.example.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.AppRepository
import com.example.data.CollectionEntry
import com.example.data.Member
import com.example.data.Role
import com.example.data.User
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.UUID

class AppViewModel(private val repository: AppRepository) : ViewModel() {

    private val _currentUser = MutableStateFlow<User?>(null)
    val currentUser: StateFlow<User?> = _currentUser.asStateFlow()

    val allMembers: StateFlow<List<Member>> = repository.allMembers
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allCollections: StateFlow<List<CollectionEntry>> = repository.allCollections
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    init {
        // Initialize default users if not present
        viewModelScope.launch {
            if (repository.getUserByUsername("admin") == null) {
                repository.insertUser(User(username = "admin", role = Role.ADMIN))
            }
            if (repository.getUserByUsername("officer") == null) {
                repository.insertUser(User(username = "officer", role = Role.OFFICER))
            }
            if (repository.getUserByUsername("member") == null) {
                val memberId = repository.insertMember(Member(name = "Test Member", qrCode = UUID.randomUUID().toString())).toInt()
                repository.insertUser(User(username = "member", role = Role.MEMBER, memberId = memberId))
            }
        }
    }

    fun login(username: String) {
        viewModelScope.launch {
            _currentUser.value = repository.getUserByUsername(username)
        }
    }

    fun logout() {
        _currentUser.value = null
    }

    fun registerMember(name: String) {
        viewModelScope.launch {
            val qrCode = UUID.randomUUID().toString()
            repository.insertMember(Member(name = name, qrCode = qrCode))
        }
    }

    fun addCollection(memberId: Int, weightKg: Double, location: String?, photoUri: String?) {
        viewModelScope.launch {
            val points = (weightKg * 10).toInt() // 10 points per KG
            val officerId = _currentUser.value?.id ?: 0
            val entry = CollectionEntry(
                memberId = memberId,
                officerId = officerId,
                weightKg = weightKg,
                points = points,
                location = location,
                photoUri = photoUri
            )
            repository.insertCollection(entry)
            repository.addPointsToMember(memberId, points)
        }
    }
}

class AppViewModelFactory(private val repository: AppRepository) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(AppViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return AppViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
