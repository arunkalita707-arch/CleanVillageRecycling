package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val Emerald50 = Color(0xFFECFDF5)
val Emerald100 = Color(0xFFD1FAE5)
val Emerald200 = Color(0xFFA7F3D0)
val Emerald600 = Color(0xFF059669)
val Emerald700 = Color(0xFF047857)
val Emerald800 = Color(0xFF065F46)
val Emerald900 = Color(0xFF064E3B)

val Orange50 = Color(0xFFFFF7ED)
val Orange100 = Color(0xFFFFEDD5)
val Orange200 = Color(0xFFFED7AA)
val Orange700 = Color(0xFFC2410C)
val Orange800 = Color(0xFF9A3412)

val AppBackground = Color(0xFFF7F9F2)
val TextPrimary = Color(0xFF1A1C18)
