package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ExitToApp
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.data.Member

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OfficerDashboard(viewModel: AppViewModel, onLogout: () -> Unit) {
    var showAddCollectionDialog by remember { mutableStateOf(false) }
    var showRegisterDialog by remember { mutableStateOf(false) }
    var selectedMemberId by remember { mutableStateOf<Int?>(null) }
    
    val members by viewModel.allMembers.collectAsState()
    var searchQuery by remember { mutableStateOf("") }
    
    val filteredMembers = members.filter { it.name.contains(searchQuery, ignoreCase = true) }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 24.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
            ) {
                Column {
                    Text("COLLECTION OFFICER", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary.copy(alpha = 0.7f), fontWeight = androidx.compose.ui.text.font.FontWeight.Bold, letterSpacing = androidx.compose.ui.unit.TextUnit(1.5f, androidx.compose.ui.unit.TextUnitType.Sp))
                    Text("Hello, Officer", style = MaterialTheme.typography.headlineSmall, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                    Box(modifier = Modifier.background(MaterialTheme.colorScheme.primaryContainer, shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)).padding(horizontal = 12.dp, vertical = 6.dp)) {
                        Text("অসমীয়া", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onPrimaryContainer, fontWeight = androidx.compose.ui.text.font.FontWeight.Medium)
                    }
                    Box(modifier = Modifier.size(40.dp).background(MaterialTheme.colorScheme.primary, shape = androidx.compose.foundation.shape.CircleShape), contentAlignment = androidx.compose.ui.Alignment.Center) {
                        Text("RB", style = MaterialTheme.typography.titleSmall, color = androidx.compose.ui.graphics.Color.White, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold)
                    }
                    IconButton(onClick = onLogout) {
                        Icon(Icons.Default.ExitToApp, contentDescription = "Logout", tint = MaterialTheme.colorScheme.primary)
                    }
                }
            }
        },
        floatingActionButton = {
            FloatingActionButton(onClick = { showRegisterDialog = true }, containerColor = MaterialTheme.colorScheme.primary) {
                Icon(Icons.Default.PersonAdd, contentDescription = "Register Member", tint = androidx.compose.ui.graphics.Color.White)
            }
        }
    ) { padding ->
        Column(modifier = Modifier.padding(padding).fillMaxSize().padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            // Hero Card
            Box(
                modifier = Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.primary, shape = androidx.compose.foundation.shape.RoundedCornerShape(32.dp)).padding(24.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(24.dp)) {
                    Column {
                        Text("Today's Collection Progress", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.9f))
                        Row(verticalAlignment = androidx.compose.ui.Alignment.Bottom, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text("142.5", style = MaterialTheme.typography.displayMedium, color = androidx.compose.ui.graphics.Color.White, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold)
                            Text("KG", style = MaterialTheme.typography.titleMedium, color = androidx.compose.ui.graphics.Color.White.copy(alpha = 0.8f), modifier = Modifier.padding(bottom = 8.dp))
                        }
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = androidx.compose.ui.Alignment.Bottom) {
                        Column {
                            Text("TOTAL POINTS ISSUED", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.7f), letterSpacing = androidx.compose.ui.unit.TextUnit(1.5f, androidx.compose.ui.unit.TextUnitType.Sp))
                            Text("2,850 pts", style = MaterialTheme.typography.titleLarge, color = androidx.compose.ui.graphics.Color.White, fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace)
                        }
                    }
                }
            }

            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                label = { Text("Search Members") },
                modifier = Modifier.fillMaxWidth(),
                shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = MaterialTheme.colorScheme.primary,
                    unfocusedBorderColor = MaterialTheme.colorScheme.primaryContainer,
                    focusedContainerColor = androidx.compose.ui.graphics.Color.White,
                    unfocusedContainerColor = androidx.compose.ui.graphics.Color.White
                )
            )
            
            Box(
                modifier = Modifier.fillMaxWidth().weight(1f).background(androidx.compose.ui.graphics.Color.White, shape = androidx.compose.foundation.shape.RoundedCornerShape(topStart = 40.dp, topEnd = 40.dp)).padding(top = 24.dp, start = 16.dp, end = 16.dp)
            ) {
                Column {
                    Row(modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                        Text("Members", style = MaterialTheme.typography.titleMedium, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)
                        Text("View All", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary, fontWeight = androidx.compose.ui.text.font.FontWeight.Medium)
                    }
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(filteredMembers) { member ->
                            MemberItem(member, onAddCollection = {
                                selectedMemberId = member.id
                                showAddCollectionDialog = true
                            })
                        }
                    }
                }
            }
        }
    }

    if (showRegisterDialog) {
        var newMemberName by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showRegisterDialog = false },
            title = { Text("Register New Member") },
            text = {
                OutlinedTextField(
                    value = newMemberName,
                    onValueChange = { newMemberName = it },
                    label = { Text("Member Name") },
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                Button(onClick = {
                    viewModel.registerMember(newMemberName)
                    showRegisterDialog = false
                }) { Text("Register") }
            },
            dismissButton = {
                TextButton(onClick = { showRegisterDialog = false }) { Text("Cancel") }
            }
        )
    }

    if (showAddCollectionDialog && selectedMemberId != null) {
        var weight by remember { mutableStateOf("") }
        var location by remember { mutableStateOf("Lat: 26.2, Lng: 91.7 (Guwahati)") }
        var points by remember { mutableStateOf(0) }
        
        AlertDialog(
            onDismissRequest = { showAddCollectionDialog = false },
            title = { Text("Plastic Collection Entry") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = weight,
                        onValueChange = { 
                            weight = it 
                            val w = it.toDoubleOrNull() ?: 0.0
                            points = (w * 10).toInt()
                        },
                        label = { Text("Weight in KG") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Text("Auto Points Calculated: $points", style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.primary)
                    OutlinedTextField(
                        value = location,
                        onValueChange = { location = it },
                        label = { Text("GPS Location") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Button(onClick = { /* Mock Photo Upload */ }, modifier = Modifier.fillMaxWidth()) {
                        Text("Upload Photo")
                    }
                }
            },
            confirmButton = {
                Button(onClick = {
                    val w = weight.toDoubleOrNull() ?: 0.0
                    if (w > 0) {
                        viewModel.addCollection(selectedMemberId!!, w, location, "content://mock_photo_uri")
                        showAddCollectionDialog = false
                    }
                }) { Text("Save Entry") }
            },
            dismissButton = {
                TextButton(onClick = { showAddCollectionDialog = false }) { Text("Cancel") }
            }
        )
    }
}

@Composable
fun MemberItem(member: Member, onAddCollection: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
        shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)
    ) {
        Row(
            modifier = Modifier.padding(16.dp).fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                Box(
                    modifier = Modifier.size(40.dp).background(androidx.compose.ui.graphics.Color.White, shape = androidx.compose.foundation.shape.RoundedCornerShape(12.dp)),
                    contentAlignment = androidx.compose.ui.Alignment.Center
                ) {
                    Text("👤", style = MaterialTheme.typography.titleMedium)
                }
                Column {
                    Text(member.name, style = MaterialTheme.typography.titleSmall, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimaryContainer)
                    Text("Total Points: ${member.totalPoints}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.7f))
                }
            }
            IconButton(
                onClick = onAddCollection,
                modifier = Modifier.background(MaterialTheme.colorScheme.primary, shape = androidx.compose.foundation.shape.CircleShape).size(36.dp)
            ) {
                Icon(Icons.Default.Add, contentDescription = "Add Collection", tint = androidx.compose.ui.graphics.Color.White)
            }
        }
    }
}
