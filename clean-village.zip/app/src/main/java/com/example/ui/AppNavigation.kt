package com.example.ui

import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.data.Role

@Composable
fun AppNavigation(viewModel: AppViewModel, modifier: Modifier = Modifier) {
    val navController = rememberNavController()
    val currentUser by viewModel.currentUser.collectAsState()

    NavHost(
        navController = navController,
        startDestination = if (currentUser == null) "login" else "home",
        modifier = modifier
    ) {
        composable("login") {
            LoginScreen(
                onLogin = { username ->
                    viewModel.login(username)
                    navController.navigate("home") {
                        popUpTo("login") { inclusive = true }
                    }
                }
            )
        }
        composable("home") {
            when (currentUser?.role) {
                Role.ADMIN -> AdminDashboard(viewModel, onLogout = {
                    viewModel.logout()
                    navController.navigate("login") {
                        popUpTo("home") { inclusive = true }
                    }
                })
                Role.OFFICER -> OfficerDashboard(viewModel, onLogout = {
                    viewModel.logout()
                    navController.navigate("login") {
                        popUpTo("home") { inclusive = true }
                    }
                })
                Role.MEMBER -> MemberDashboard(viewModel, onLogout = {
                    viewModel.logout()
                    navController.navigate("login") {
                        popUpTo("home") { inclusive = true }
                    }
                })
                null -> {}
            }
        }
    }
}
